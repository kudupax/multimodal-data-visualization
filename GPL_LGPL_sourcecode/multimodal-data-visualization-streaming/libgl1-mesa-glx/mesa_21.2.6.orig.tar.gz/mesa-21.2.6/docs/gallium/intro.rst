Introduction
============

What is Gallium?
----------------

Gallium is essentially an API for writing graphics drivers in a largely
device-agnostic fashion. It provides several objects which encapsulate the
core services of graphics hardware in a straightforward manner.
