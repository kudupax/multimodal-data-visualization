#!/bin/sh

set -e

./testgldispatch -g
./testgldispatch -g -l

