#!/bin/sh

. $TOP_SRCDIR/tests/glxenv.sh

./testglxgetclientstr
