#!/bin/sh

set -e

./testgldispatch -s -g -p -t
./testgldispatch -s -g -p -t -l

