Permission to Relicense under MPLv2

This is a statement by Wojciech Kula that grants permission to relicense its copyrights in the libzmq C++ library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "Cziken", with commit author "Cziken wojciech_kula@o2.pl", are copyright of Wojciech Kula. This document hereby grants the libzmq project team to relicense libzmq, including all past, present and future contributions of the author listed above.

Wojciech Kula 2021/01/13
