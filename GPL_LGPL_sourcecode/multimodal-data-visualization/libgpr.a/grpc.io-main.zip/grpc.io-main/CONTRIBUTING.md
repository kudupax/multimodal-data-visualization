# How to contribute

We definitely welcome patches and contributions to grpc.io! Please read the gRPC
organization's [governance rules](https://github.com/grpc/grpc-community/blob/main/governance.md)
and [contribution guidelines](https://github.com/grpc/grpc-community/blob/main/CONTRIBUTING.md) before proceeding.
