---
title: C#
description: The original core-library implementation of gRPC for C#
api_path: grpc/LANG/api/Grpc.Core
prog_lang_home: true
src_repo: https://github.com/grpc/grpc
content:
  - learn_more:
    - "[Additional docs]($src_repo_url/tree/master/doc/csharp)"
    - "[Examples]($src_repo_url/tree/master/examples/csharp)"
  - reference:
    - "[API](api/)"
  - other:
    - "[gRPC for .NET](dotnet/)"
    - "[grpc repo]($src_repo_url)"
    - "[Daily builds](daily-builds)"
cascade:
  - show_banner: true
---

{{% docs/prog-lang-home-content %}}
